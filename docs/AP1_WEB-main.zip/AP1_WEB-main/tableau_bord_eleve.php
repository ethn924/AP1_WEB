<?php
require_once '_conf.php';
require_once 'fonctions.php';

if (!$loggedIn || $userType !== 0) {
    header('Location: index.php');
    exit;
}

$pageTitle = 'Tableau de Bord - Étudiant';
require_once 'header.php';

$crs = getUserCRs($userId);
$brouillon = $soumis = $en_eval = $approuve = 0;

foreach ($crs as $cr) {
    if ($cr['statut'] === 'brouillon') $brouillon++;
    elseif ($cr['statut'] === 'soumis') $soumis++;
    elseif ($cr['statut'] === 'en_evaluation') $en_eval++;
    elseif ($cr['statut'] === 'approuve') $approuve++;
}

$notifications = getUserNotifications($userId, 5);
?>

<div class="page-header">
    <h1>📊 Tableau de Bord</h1>
    <p>Vue d'ensemble de vos comptes rendus</p>
</div>

<div class="grid grid-4 mb-4">
    <div class="stat-card">
        <div class="stat-number"><?php echo count($crs); ?></div>
        <div class="stat-label">Total CR</div>
    </div>
    <div class="stat-card">
        <div class="stat-number" style="color: #6c757d;"><?php echo $brouillon; ?></div>
        <div class="stat-label">Brouillons</div>
    </div>
    <div class="stat-card">
        <div class="stat-number" style="color: #17a2b8;"><?php echo $soumis; ?></div>
        <div class="stat-label">Soumis</div>
    </div>
    <div class="stat-card">
        <div class="stat-number" style="color: #ffc107;"><?php echo $en_eval; ?></div>
        <div class="stat-label">En évaluation</div>
    </div>
    <div class="stat-card">
        <div class="stat-number" style="color: #28a745;"><?php echo $approuve; ?></div>
        <div class="stat-label">Approuvés</div>
    </div>
</div>

<div class="d-grid gap-4" style="grid-template-columns: 2fr 1fr;">
    <!-- Mes CR Récents -->
    <div class="card">
        <div class="card-header">
            📋 Mes Comptes Rendus Récents
            <a href="liste_cr.php" class="btn btn-sm btn-outline" style="float: right;">Voir tous</a>
        </div>
        <div class="card-body">
            <?php if (empty($crs)): ?>
                <div class="alert alert-info">
                    Aucun compte rendu créé. <a href="editer_cr.php">Créer un nouveau CR</a>
                </div>
            <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Titre</th>
                            <th>Statut</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (array_slice($crs, 0, 5) as $cr): ?>
                        <tr>
                            <td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis;">
                                <?php echo htmlspecialchars(substr($cr['titre'] ?? 'Sans titre', 0, 50)); ?>
                            </td>
                            <td>
                                <span class="status-badge status-<?php echo str_replace('_', '-', $cr['statut'] ?? 'draft'); ?>">
                                    <?php 
                                    $statuts = ['brouillon' => 'Brouillon', 'soumis' => 'Soumis', 'en_evaluation' => 'En éval.', 'approuve' => 'Approuvé'];
                                    echo $statuts[$cr['statut']] ?? $cr['statut'];
                                    ?>
                                </span>
                            </td>
                            <td style="font-size: 0.9em; color: #666;">
                                <?php echo formatDate($cr['datetime'] ?? $cr['date'] ?? null); ?>
                            </td>
                            <td>
                                <a href="editer_cr.php?id=<?php echo $cr['num']; ?>" class="btn btn-sm btn-primary">✏️</a>
                                <a href="liste_cr.php?detail=<?php echo $cr['num']; ?>" class="btn btn-sm btn-secondary">👁</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- Notifications -->
    <div class="card">
        <div class="card-header">
            🔔 Notifications Récentes
            <a href="notifications.php" class="btn btn-sm btn-outline" style="float: right;">Voir tout</a>
        </div>
        <div class="card-body">
            <?php if (empty($notifications)): ?>
                <div style="text-align: center; color: #999; padding: 20px;">
                    Aucune notification
                </div>
            <?php else: ?>
                <?php foreach ($notifications as $notif): ?>
                <div style="padding: 12px 0; border-bottom: 1px solid var(--border);">
                    <div style="font-weight: 600; font-size: 0.95em; color: var(--dark);">
                        <?php echo htmlspecialchars($notif['titre'] ?? 'Notification'); ?>
                    </div>
                    <small style="color: #999;">
                        <?php echo formatDate($notif['date_creation'] ?? null); ?>
                    </small>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Actions Rapides -->
<div class="card mt-4">
    <div class="card-header">⚡ Actions Rapides</div>
    <div class="card-body">
        <div class="d-grid gap-3" style="grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));">
            <a href="editer_cr.php" class="btn btn-primary">+ Créer un CR</a>
            <a href="liste_cr.php" class="btn btn-secondary">📋 Voir mes CR</a>
            <a href="mon_stage.php" class="btn btn-secondary">🏢 Mon Stage</a>
            <a href="perso.php" class="btn btn-secondary">👤 Mon Profil</a>
            <a href="notifications.php" class="btn btn-secondary">🔔 Notifications</a>
            <a href="accueil.php" class="btn btn-secondary">🏠 Accueil</a>
        </div>
    </div>
</div>

</main>

<?php require_once 'footer.php'; ?>
