<?php
require_once '_conf.php';
require_once 'fonctions.php';

if ($loggedIn) {
    header('Location: ' . ($userType === 1 ? 'tableau_bord_prof.php' : 'tableau_bord_eleve.php'));
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login'] ?? '';
    $email = $_POST['email'] ?? '';
    $nom = $_POST['nom'] ?? '';
    $prenom = $_POST['prenom'] ?? '';
    $password = $_POST['password'] ?? '';
    $type = $_POST['type'] ?? '0';
    
    if (empty($login) || empty($email) || empty($nom) || empty($prenom) || empty($password)) {
        $error = 'Tous les champs sont obligatoires';
    } elseif (strlen($password) < 4) {
        $error = 'Le mot de passe doit contenir au moins 4 caractères';
    } else {
        $login = echapper($login);
        $email = echapper($email);
        $nom = echapper($nom);
        $prenom = echapper($prenom);
        $password = md5($password);
        $type = (int)$type;
        
        $check = mysqli_query($conn, "SELECT num FROM utilisateur WHERE login='$login' OR email='$email'");
        
        if (mysqli_num_rows($check) > 0) {
            $error = 'Login ou email déjà utilisé';
        } else {
            $query = "INSERT INTO utilisateur (login, email, nom, prenom, mdp, type, verified) 
                      VALUES ('$login', '$email', '$nom', '$prenom', '$password', $type, 1)";
            
            if (mysqli_query($conn, $query)) {
                $success = 'Compte créé avec succès ! <a href="index.php">Cliquez ici pour vous connecter</a>';
            } else {
                $error = 'Erreur lors de la création du compte';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription - Portail CR</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
            min-height: 100vh;
            padding: 2rem 0;
        }
        .signup-container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            max-width: 450px;
            margin: auto;
        }
        .signup-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        .signup-header h1 {
            color: #007bff;
            font-size: 1.8rem;
            font-weight: 700;
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0,123,255,0.25);
        }
        .btn-signup {
            background-color: #007bff;
            border: none;
            padding: 0.75rem;
            font-weight: 600;
            width: 100%;
        }
        .btn-signup:hover {
            background-color: #0056b3;
        }
        .login-link {
            text-align: center;
            margin-top: 1rem;
        }
        .login-link a {
            color: #007bff;
            text-decoration: none;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="signup-container">
        <div class="signup-header">
            <h1>📚 S'inscrire</h1>
            <p class="text-muted">Créer un nouveau compte</p>
        </div>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if (!empty($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php else: ?>
            <form method="POST">
                <div class="mb-2">
                    <label for="login" class="form-label">Login</label>
                    <input type="text" class="form-control" id="login" name="login" required>
                </div>
                
                <div class="mb-2">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-2">
                        <label for="nom" class="form-label">Nom</label>
                        <input type="text" class="form-control" id="nom" name="nom" required>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="prenom" class="form-label">Prénom</label>
                        <input type="text" class="form-control" id="prenom" name="prenom" required>
                    </div>
                </div>
                
                <div class="mb-2">
                    <label for="password" class="form-label">Mot de passe</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                
                <div class="mb-3">
                    <label for="type" class="form-label">Type de compte</label>
                    <select class="form-select" id="type" name="type">
                        <option value="0">Étudiant</option>
                        <option value="1">Enseignant</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary btn-signup">S'inscrire</button>
            </form>
        <?php endif; ?>
        
        <div class="login-link">
            <p class="mb-0">Déjà inscrit ? <a href="index.php">Se connecter</a></p>
        </div>
    </div>
</body>
</html>
