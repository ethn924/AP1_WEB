<?php
require_once '_conf.php';
require_once 'fonctions.php';

if (!$loggedIn) {
    header('Location: index.php');
    exit;
}

$pageTitle = 'Accueil - Portail Comptes Rendus';
require_once 'header.php';
?>

<div class="page-header">
    <h1>Bienvenue 👋</h1>
    <p><?php echo $userType == 1 ? 'Espace Enseignant' : 'Espace Étudiant'; ?> - <?php echo htmlspecialchars($userName); ?></p>
</div>

<?php if ($userType == 0): ?>
<!-- ESPACE ÉTUDIANT -->
<div class="grid grid-3">
    <a href="editer_cr.php" class="card card-link">
        <div class="card-body text-center">
            <div class="card-emoji">📝</div>
            <h5 class="card-title">Créer un CR</h5>
            <p class="card-text">Rédigez un nouveau compte rendu</p>
        </div>
    </a>

    <a href="liste_cr.php" class="card card-link">
        <div class="card-body text-center">
            <div class="card-emoji">📋</div>
            <h5 class="card-title">Mes CR</h5>
            <p class="card-text">Consultez tous vos comptes rendus</p>
        </div>
    </a>

    <a href="tableau_bord_eleve.php" class="card card-link">
        <div class="card-body text-center">
            <div class="card-emoji">📊</div>
            <h5 class="card-title">Tableau de Bord</h5>
            <p class="card-text">Vue d'ensemble de vos CR</p>
        </div>
    </a>

    <a href="mon_stage.php" class="card card-link">
        <div class="card-body text-center">
            <div class="card-emoji">🏢</div>
            <h5 class="card-title">Mon Stage</h5>
            <p class="card-text">Gérez vos infos de stage</p>
        </div>
    </a>

    <a href="notifications.php" class="card card-link">
        <div class="card-body text-center">
            <div class="card-emoji">🔔</div>
            <h5 class="card-title">Notifications</h5>
            <p class="card-text">Consultez vos messages</p>
        </div>
    </a>

    <a href="perso.php" class="card card-link">
        <div class="card-body text-center">
            <div class="card-emoji">👤</div>
            <h5 class="card-title">Mon Profil</h5>
            <p class="card-text">Modifier mes informations</p>
        </div>
    </a>
</div>

<?php else: ?>
<!-- ESPACE ENSEIGNANT -->
<div class="grid grid-3">
    <a href="liste_cr_prof.php" class="card card-link">
        <div class="card-body text-center">
            <div class="card-emoji">✅</div>
            <h5 class="card-title">Évaluer les CR</h5>
            <p class="card-text">Corriger et évaluer les CR</p>
        </div>
    </a>

    <a href="gestion_groupes.php" class="card card-link">
        <div class="card-body text-center">
            <div class="card-emoji">👥</div>
            <h5 class="card-title">Groupes</h5>
            <p class="card-text">Gérer les groupes d'étudiants</p>
        </div>
    </a>

    <a href="liste_eleves.php" class="card card-link">
        <div class="card-body text-center">
            <div class="card-emoji">🎓</div>
            <h5 class="card-title">Étudiants</h5>
            <p class="card-text">Liste des étudiants</p>
        </div>
    </a>

    <a href="tableau_bord_prof.php" class="card card-link">
        <div class="card-body text-center">
            <div class="card-emoji">📊</div>
            <h5 class="card-title">Tableau de Bord</h5>
            <p class="card-text">Statistiques et graphiques</p>
        </div>
    </a>

    <a href="gestion_modeles.php" class="card card-link">
        <div class="card-body text-center">
            <div class="card-emoji">📝</div>
            <h5 class="card-title">Modèles</h5>
            <p class="card-text">Gérer les modèles de CR</p>
        </div>
    </a>

    <a href="gestion_rappels.php" class="card card-link">
        <div class="card-body text-center">
            <div class="card-emoji">🔔</div>
            <h5 class="card-title">Rappels</h5>
            <p class="card-text">Créer des rappels de deadline</p>
        </div>
    </a>

    <a href="recherche_cr.php" class="card card-link">
        <div class="card-body text-center">
            <div class="card-emoji">🔍</div>
            <h5 class="card-title">Recherche</h5>
            <p class="card-text">Rechercher et filtrer les CR</p>
        </div>
    </a>

    <a href="analytics_advanced.php" class="card card-link">
        <div class="card-body text-center">
            <div class="card-emoji">📈</div>
            <h5 class="card-title">Analytics</h5>
            <p class="card-text">Analyses détaillées</p>
        </div>
    </a>

    <a href="gestion_audit.php" class="card card-link">
        <div class="card-body text-center">
            <div class="card-emoji">📋</div>
            <h5 class="card-title">Audit</h5>
            <p class="card-text">Historique des actions</p>
        </div>
    </a>
</div>
<?php endif; ?>

</main>

<?php require_once 'footer.php'; ?>
