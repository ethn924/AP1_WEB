<?php
require_once '_conf.php';
require_once 'fonctions.php';

if (!$loggedIn || $userType !== 1) {
    header('Location: index.php');
    exit;
}

$pageTitle = 'Comptes Rendus des Élèves';
require_once 'header.php';

$bdd = $conn;
$teacher_id = $userId;

if (isset($_POST['update_vu'])) {
    $crn = (int)$_POST['cr_num'];
    $vu = (int)$_POST['vu_value'];
    if (mysqli_query($bdd, "UPDATE cr SET vu = $vu WHERE num = $crn")) {
        $d = mysqli_fetch_assoc(mysqli_query($bdd, "SELECT num_utilisateur FROM cr WHERE num = $crn"));
        if ($vu == 1) creerNotificationAvecAuteur($d['num_utilisateur'], 'cr_vu', 'CR consulté', 'Un professeur a consulté votre CR.', $teacher_id, 'liste_cr.php?detail=' . $crn);
    }
}

if (isset($_POST['ajouter_commentaire'])) {
    $crn = (int)$_POST['cr_num'];
    $com = q($_POST['commentaire']);
    if (ajouterCommentaire($crn, $teacher_id, $com)) {
        $d = mysqli_fetch_assoc(mysqli_query($bdd, "SELECT num_utilisateur FROM cr WHERE num = $crn"));
        creerNotificationAvecAuteur($d['num_utilisateur'], 'commentaire', 'Commentaire ajouté', 'Un professeur a ajouté un commentaire.', $teacher_id, 'liste_cr.php?detail=' . $crn);
    }
}

$eleves = fetchAll("SELECT DISTINCT u.num, u.nom, u.prenom FROM utilisateur u JOIN cr ON cr.num_utilisateur = u.num WHERE u.type = 0 ORDER BY u.nom ASC, u.prenom ASC");

$filters = [];
if (isset($_GET['eleve']) && !empty($_GET['eleve'])) $filters['user_id'] = (int)$_GET['eleve'];
if (isset($_GET['search']) && !empty($_GET['search'])) $filters['search'] = $_GET['search'];
if (isset($_GET['sort'])) {
    if ($_GET['sort'] === 'vu') $filters['vu'] = 1;
    elseif ($_GET['sort'] === 'non_vu') $filters['vu'] = 0;
    else $filters['sort'] = $_GET['sort'];
}

$crs = getAllCRsForTeacher($filters);
$cr_detail = null;
if (isset($_GET['view']) && !empty($_GET['view'])) {
    $cr_detail = getCRWithStudent((int)$_GET['view']);
}
?>

<div class="page-header">
    <h1>📋 Comptes Rendus des Élèves</h1>
    <p>Révisez et annotez les travaux de vos étudiants</p>
</div>

<!-- Filtres et Recherche -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
            <input type="text" name="search" placeholder="Rechercher dans les CR..." 
                value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>"
                style="flex: 1; min-width: 200px; padding: 8px 12px; border: 1px solid var(--border); border-radius: 6px;">
            <button type="submit" class="btn btn-primary">🔍 Rechercher</button>
            <?php if (isset($_GET['search']) && !empty($_GET['search'])): ?>
                <a href="liste_cr_prof.php" class="btn btn-secondary">✕ Réinitialiser</a>
            <?php endif; ?>
        </form>

        <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-top: 12px;">
            <a href="?sort=date_desc" class="btn <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'date_desc') ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Date (récents)</a>
            <a href="?sort=date_asc" class="btn <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'date_asc') ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Date (anciens)</a>
            <a href="?sort=eleve" class="btn <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'eleve') ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Élève (A-Z)</a>
            <a href="?sort=non_vu" class="btn <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'non_vu') ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">Non consultés</a>
            <a href="liste_cr_prof.php" class="btn btn-secondary btn-sm">Tous</a>
        </div>

        <?php if (!empty($eleves)): ?>
        <form method="GET" style="margin-top: 12px;">
            <select name="eleve" onchange="this.form.submit();" style="padding: 8px; border: 1px solid var(--border); border-radius: 6px;">
                <option value="">-- Tous les élèves --</option>
                <?php foreach ($eleves as $eleve): ?>
                    <option value="<?php echo $eleve['num']; ?>" <?php echo (isset($_GET['eleve']) && $_GET['eleve'] == $eleve['num']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($eleve['prenom'] . ' ' . $eleve['nom']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
        <?php endif; ?>
    </div>
</div>

<!-- Liste des CR -->
<?php if (!empty($crs)): ?>
<div class="card">
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Élève</th>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($crs as $cr): 
                    $commentaires = getCommentaires($cr['num']);
                    $pieces_jointes = getPiecesJointes($cr['num']);
                ?>
                <tr>
                    <td>
                        <strong><?php echo htmlspecialchars($cr['prenom'] . ' ' . $cr['nom']); ?></strong>
                    </td>
                    <td style="font-size: 0.9em; color: #666;">
                        <?php echo formatDate($cr['datetime']); ?>
                    </td>
                    <td style="max-width: 300px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        <?php 
                        $desc = strip_tags($cr['description'] ?? '');
                        echo htmlspecialchars(substr($desc, 0, 60) . (strlen($desc) > 60 ? '...' : ''));
                        ?>
                    </td>
                    <td>
                        <?php if ($cr['vu']): ?>
                            <span class="status-badge status-approved">✅ Consulté</span>
                        <?php else: ?>
                            <span class="status-badge status-draft">⏳ Non consulté</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="?view=<?php echo $cr['num']; ?>" class="btn btn-sm btn-primary">Voir détails</a>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="cr_num" value="<?php echo $cr['num']; ?>">
                            <input type="hidden" name="vu_value" value="<?php echo $cr['vu'] ? '0' : '1'; ?>">
                            <button type="submit" name="update_vu" class="btn btn-sm <?php echo $cr['vu'] ? 'btn-secondary' : 'btn-success'; ?>">
                                <?php echo $cr['vu'] ? 'Marquer non vu' : 'Marquer vu'; ?>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php else: ?>
<div class="card">
    <div class="card-body text-center" style="padding: 50px 20px;">
        <p style="color: #999;">Aucun compte rendu trouvé</p>
    </div>
</div>
<?php endif; ?>

<!-- Modal pour le détail du CR -->
<?php if ($cr_detail): 
    $commentaires = getCommentaires($cr_detail['num']);
    $pieces_jointes = getPiecesJointes($cr_detail['num']);
?>
<div class="modal-overlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center; overflow-y: auto; padding: 20px;">
    <div class="modal-content" style="background: white; border-radius: 8px; max-width: 800px; width: 100%; box-shadow: var(--shadow-lg);">
        <div style="background: var(--primary); padding: 20px; border-radius: 8px 8px 0 0; display: flex; justify-content: space-between; align-items: center;">
            <h2 style="margin: 0; color: white;">📋 <?php echo htmlspecialchars($cr_detail['titre'] ?? 'Compte Rendu'); ?></h2>
            <a href="liste_cr_prof.php" style="color: white; font-size: 1.8em; text-decoration: none; cursor: pointer;">✕</a>
        </div>

        <div style="padding: 20px; max-height: 70vh; overflow-y: auto;">
            <div class="card mb-3">
                <div class="card-header">📄 Informations</div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label style="color: var(--primary); font-weight: 600;">Élève</label>
                            <p style="margin: 5px 0;"><?php echo htmlspecialchars($cr_detail['prenom'] . ' ' . $cr_detail['nom']); ?></p>
                        </div>
                        <div>
                            <label style="color: var(--primary); font-weight: 600;">Date</label>
                            <p style="margin: 5px 0;"><?php echo formatDate($cr_detail['datetime']); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">📝 Description</div>
                <div class="card-body">
                    <p style="color: #666; line-height: 1.6;"><?php echo nl2br(htmlspecialchars($cr_detail['description'])); ?></p>
                </div>
            </div>

            <?php if (!empty($pieces_jointes)): ?>
            <div class="card mb-3">
                <div class="card-header">📎 Pièces jointes</div>
                <div class="card-body">
                    <?php foreach ($pieces_jointes as $piece): ?>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px; background: #f9fafb; border-radius: 4px; margin-bottom: 6px;">
                            <span>📄 <?php echo htmlspecialchars($piece['nom_fichier']); ?></span>
                            <a href="telecharger.php?id=<?php echo $piece['id']; ?>" target="_blank" class="btn btn-sm btn-info">⬇️</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="card mb-3">
                <div class="card-header">💬 Commentaires</div>
                <div class="card-body">
                    <?php if (!empty($commentaires)): ?>
                        <div style="display: flex; flex-direction: column; gap: 12px; margin-bottom: 20px;">
                            <?php foreach ($commentaires as $commentaire): ?>
                                <div style="padding: 12px; background: #f9fafb; border-left: 3px solid var(--info); border-radius: 4px;">
                                    <strong><?php echo htmlspecialchars($commentaire['prenom'] . ' ' . $commentaire['nom']); ?></strong>
                                    <span style="color: #999; font-size: 0.85em;"> — <?php echo formatDate($commentaire['date_creation']); ?></span>
                                    <p style="margin: 8px 0 0 0; color: #555;"><?php echo nl2br(htmlspecialchars($commentaire['commentaire'])); ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST">
                        <input type="hidden" name="cr_num" value="<?php echo $cr_detail['num']; ?>">
                        <textarea name="commentaire" rows="4" placeholder="Ajouter un commentaire..." 
                            style="width: 100%; padding: 10px; border: 1px solid var(--border); border-radius: 6px; margin-bottom: 10px; font-family: inherit;"></textarea>
                        <button type="submit" name="ajouter_commentaire" class="btn btn-success">Ajouter le commentaire</button>
                    </form>
                </div>
            </div>

            <form method="POST">
                <input type="hidden" name="cr_num" value="<?php echo $cr_detail['num']; ?>">
                <input type="hidden" name="vu_value" value="<?php echo $cr_detail['vu'] ? '0' : '1'; ?>">
                <button type="submit" name="update_vu" class="btn <?php echo $cr_detail['vu'] ? 'btn-secondary' : 'btn-success'; ?>">
                    <?php echo $cr_detail['vu'] ? '⏳ Marquer comme non consulté' : '✅ Marquer comme consulté'; ?>
                </button>
                <a href="liste_cr_prof.php" class="btn btn-outline">Fermer</a>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

</main>

<?php require_once 'footer.php'; ?>
