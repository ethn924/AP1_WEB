    </main>
    <footer>
        <p>&copy; 2025 Portail de Gestion des Comptes Rendus - Tous droits réservés</p>
    </footer>
</body>
</html>
