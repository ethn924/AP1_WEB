<?php
require_once '_conf.php';
require_once 'fonctions.php';

if (!$loggedIn) {
    header('Location: index.php');
    exit;
}

$pageTitle = 'Notifications';
require_once 'header.php';

$notifications = getUserNotifications($userId, 100);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $notif_id = (int)($_POST['notif_id'] ?? 0);
    if ($notif_id > 0) {
        markNotificationAsRead($notif_id);
    }
}
?>

<h3 class="mb-4">🔔 Notifications</h3>

<?php if (empty($notifications)): ?>
    <div class="alert alert-light">Aucune notification</div>
<?php else: ?>
    <div class="list-group">
        <?php foreach ($notifications as $notif): ?>
        <div class="notification-item <?php echo $notif['lue'] ? 'read' : 'unread'; ?>">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <strong><?php echo htmlspecialchars($notif['titre']); ?></strong>
                    <p class="mb-1"><?php echo htmlspecialchars($notif['message']); ?></p>
                    <small class="text-muted"><?php echo formatDate($notif['date_creation']); ?></small>
                </div>
                <?php if (!$notif['lue']): ?>
                <form method="POST" style="margin: 0;">
                    <input type="hidden" name="notif_id" value="<?php echo $notif['id']; ?>">
                    <button type="submit" class="btn btn-sm btn-link">Marquer comme lue</button>
                </form>
                <?php endif; ?>
            </div>
            <?php if ($notif['lien']): ?>
                <a href="<?php echo htmlspecialchars($notif['lien']); ?>" class="btn btn-sm btn-info mt-2">Voir →</a>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once 'footer.php'; ?>
