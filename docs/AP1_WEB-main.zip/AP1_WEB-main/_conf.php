<?php
session_start();

$db_host = 'localhost';
$db_user = 'root';
$db_pass = 'root';
$db_name = 'ap1_ethan_2025';

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$conn) {
    die('Erreur connexion: ' . mysqli_connect_error());
}

mysqli_set_charset($conn, 'utf8mb4');

define('SITE_URL', 'http://localhost/PROJET_ETHAN_AP1');
define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('MAX_FILE_SIZE', 10485760);

$loggedIn = isset($_SESSION['user_id']);
$userType = $_SESSION['user_type'] ?? null;
$userId = $_SESSION['user_id'] ?? null;
$userName = $_SESSION['user_name'] ?? null;
?>
