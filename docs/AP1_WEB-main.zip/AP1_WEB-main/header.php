<?php
require_once '_conf.php';
require_once 'fonctions.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? 'Portail Comptes Rendus'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <?php if ($loggedIn): ?>
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="accueil.php">📚 Portail CR</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <?php if ($userType === 0): ?>
                        <li class="nav-item"><a class="nav-link" href="liste_cr.php">Mes CR</a></li>
                        <li class="nav-item"><a class="nav-link" href="editer_cr.php">+ Nouveau</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="liste_cr_prof.php">Correction</a></li>
                        <li class="nav-item"><a class="nav-link" href="gestion_groupes.php">Groupes</a></li>
                    <?php endif; ?>
                    
                    <li class="nav-item dropdown notification-dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="notificationDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            🔔
                            <?php 
                            $unread = getUnreadNotificationsCount($userId);
                            if ($unread > 0) echo "<span class='badge bg-danger'>$unread</span>";
                            ?>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end notification-panel" aria-labelledby="notificationDropdown">
                            <div class="notification-header">
                                <h6>Notifications</h6>
                                <?php if ($unread > 0): ?>
                                    <a href="notifications.php?action=mark_all_read" class="btn-notification-clear">Marquer tout comme lu</a>
                                <?php endif; ?>
                            </div>
                            <div class="notification-list">
                                <?php 
                                $recent_notifs = getUserNotifications($userId, 5);
                                if (!empty($recent_notifs)):
                                    foreach ($recent_notifs as $notif):
                                        $is_read = !empty($notif['lu_le']);
                                        $class = $is_read ? 'notification-item read' : 'notification-item unread';
                                ?>
                                    <a href="notifications.php" class="<?php echo $class; ?>">
                                        <div class="notif-content">
                                            <strong><?php echo htmlspecialchars($notif['titre']); ?></strong>
                                            <p><?php echo htmlspecialchars(substr($notif['message'], 0, 60) . (strlen($notif['message']) > 60 ? '...' : '')); ?></p>
                                            <small><?php echo date('d/m H:i', strtotime($notif['date_creation'])); ?></small>
                                        </div>
                                        <?php if (!$is_read): ?>
                                            <span class="notif-indicator"></span>
                                        <?php endif; ?>
                                    </a>
                                <?php 
                                    endforeach;
                                else:
                                ?>
                                    <div class="notification-item">
                                        <p style="text-align: center; color: #999; margin: 0;">Aucune notification</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="notification-footer">
                                <a href="notifications.php" class="btn-view-all">Voir tous</a>
                            </div>
                        </div>
                    </li>
                    
                    <li class="nav-item dropdown user-dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            👤 <?php echo htmlspecialchars($userName); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="perso.php">Mon Profil</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="deconnexion.php">Déconnexion</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <?php endif; ?>
    <main class="container-fluid">
