<?php
require_once '_conf.php';
require_once 'fonctions.php';

if (!$loggedIn || $userType !== 1) {
    header('Location: index.php');
    exit;
}

$pageTitle = 'Tableau de Bord - Enseignant';
require_once 'header.php';

$all_crs = getAllCRsForTeacher($userId);
$en_eval = $approuve = $soumis = 0;

foreach ($all_crs as $cr) {
    if ($cr['statut'] === 'en_evaluation') $en_eval++;
    elseif ($cr['statut'] === 'approuve') $approuve++;
    elseif ($cr['statut'] === 'soumis') $soumis++;
}

$to_correct = array_filter($all_crs, fn($cr) => $cr['statut'] === 'soumis');
?>

<div class="page-header">
    <h1>📊 Tableau de Bord Enseignant</h1>
    <p>Vue d'ensemble des comptes rendus à corriger</p>
</div>

<div class="grid grid-4 mb-4">
    <div class="stat-card">
        <div class="stat-number"><?php echo count($all_crs); ?></div>
        <div class="stat-label">Total CR</div>
    </div>
    <div class="stat-card">
        <div class="stat-number" style="color: #17a2b8;"><?php echo $soumis; ?></div>
        <div class="stat-label">À évaluer</div>
    </div>
    <div class="stat-card">
        <div class="stat-number" style="color: #ffc107;"><?php echo $en_eval; ?></div>
        <div class="stat-label">En évaluation</div>
    </div>
    <div class="stat-card">
        <div class="stat-number" style="color: #28a745;"><?php echo $approuve; ?></div>
        <div class="stat-label">Approuvés</div>
    </div>
</div>

<!-- CR à Corriger -->
<div class="card mb-4">
    <div class="card-header">
        📝 Comptes Rendus à Corriger
        <a href="liste_cr_prof.php" class="btn btn-sm btn-outline" style="float: right;">Voir tous</a>
    </div>
    <div class="card-body">
        <?php if (empty($to_correct)): ?>
            <div class="alert alert-info">
                Aucun CR en attente de correction
            </div>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Étudiant</th>
                        <th>Titre</th>
                        <th>Soumis le</th>
                        <th>Commentaires</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach (array_slice($to_correct, 0, 10) as $cr): ?>
                    <tr>
                        <td><?php echo htmlspecialchars(($cr['prenom'] ?? '') . ' ' . ($cr['nom'] ?? 'Inconnu')); ?></td>
                        <td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis;">
                            <?php echo htmlspecialchars(substr($cr['titre'] ?? 'Sans titre', 0, 40)); ?>
                        </td>
                        <td style="font-size: 0.9em; color: #666;">
                            <?php echo formatDate($cr['datetime'] ?? $cr['date'] ?? null); ?>
                        </td>
                        <td>
                            <span class="badge badge-info"><?php echo $cr['nb_comments'] ?? 0; ?></span>
                        </td>
                        <td>
                            <a href="liste_cr_prof.php?id=<?php echo $cr['num']; ?>" class="btn btn-sm btn-primary">Corriger</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<!-- Actions Rapides -->
<div class="card">
    <div class="card-header">⚡ Actions Rapides</div>
    <div class="card-body">
        <div class="d-grid gap-3" style="grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));">
            <a href="liste_cr_prof.php" class="btn btn-primary">✅ Évaluer les CR</a>
            <a href="gestion_groupes.php" class="btn btn-secondary">👥 Groupes</a>
            <a href="liste_eleves.php" class="btn btn-secondary">🎓 Étudiants</a>
            <a href="gestion_modeles.php" class="btn btn-secondary">📝 Modèles</a>
            <a href="gestion_rappels.php" class="btn btn-secondary">🔔 Rappels</a>
            <a href="accueil.php" class="btn btn-secondary">🏠 Accueil</a>
        </div>
    </div>
</div>

</main>

<?php require_once 'footer.php'; ?>
