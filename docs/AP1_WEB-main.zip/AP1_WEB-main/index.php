<?php
require_once '_conf.php';
require_once 'fonctions.php';

if ($loggedIn) {
    header('Location: ' . ($userType === 1 ? 'tableau_bord_prof.php' : 'tableau_bord_eleve.php'));
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($login) || empty($password)) {
        $error = 'Veuillez remplir tous les champs';
    } else {
        $user = verifyPassword($login, $password);
        
        if ($user && $user['verified'] == 1) {
            $_SESSION['user_id'] = $user['num'];
            $_SESSION['user_type'] = $user['type'];
            $_SESSION['user_name'] = $user['nom'] . ' ' . $user['prenom'];
            
            header('Location: ' . ($user['type'] === 1 ? 'tableau_bord_prof.php' : 'tableau_bord_eleve.php'));
            exit;
        } elseif ($user && $user['verified'] == 0) {
            $error = 'Veuillez vérifier votre email avant de vous connecter';
        } else {
            $error = 'Identifiants incorrects';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Portail CR</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            max-width: 400px;
            width: 100%;
        }
        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        .login-header h1 {
            color: #007bff;
            font-size: 2rem;
            font-weight: 700;
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0,123,255,0.25);
        }
        .btn-login {
            background-color: #007bff;
            border: none;
            padding: 0.75rem;
            font-weight: 600;
            width: 100%;
        }
        .btn-login:hover {
            background-color: #0056b3;
        }
        .signup-link {
            text-align: center;
            margin-top: 1.5rem;
        }
        .signup-link a {
            color: #007bff;
            text-decoration: none;
            font-weight: 600;
        }
        .signup-link a:hover {
            text-decoration: underline;
        }
        .alert {
            border-radius: 4px;
            border: none;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>📚 Portail CR</h1>
            <p class="text-muted">Gestion des Comptes Rendus</p>
        </div>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label for="login" class="form-label">Login</label>
                <input type="text" class="form-control" id="login" name="login" required autofocus>
            </div>
            
            <div class="mb-3">
                <label for="password" class="form-label">Mot de passe</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            
            <button type="submit" class="btn btn-primary btn-login">Connexion</button>
        </form>
        
        <div class="signup-link">
            <p class="mb-0">Pas encore de compte ? <a href="inscription.php">S'inscrire</a></p>
        </div>
    </div>
</body>
</html>
