<?php
require_once '_conf.php';
require_once 'fonctions.php';

if (!$loggedIn) {
    header('Location: index.php');
    exit;
}

$pageTitle = 'Mon Profil';
require_once 'header.php';

$user = getUser($userId);
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_password = $_POST['password'] ?? '';
    
    if (!empty($new_password)) {
        if (strlen($new_password) < 4) {
            $message = '<div class="alert alert-danger">Mot de passe trop court</div>';
        } else {
            $new_pass_md5 = md5($new_password);
            mysqli_query($conn, "UPDATE utilisateur SET mdp='$new_pass_md5' WHERE num=$userId");
            $message = '<div class="alert alert-success">Mot de passe mis à jour !</div>';
        }
    }
}
?>

<h3 class="mb-4">👤 Mon Profil</h3>

<?php echo $message; ?>

<div class="row">
    <div class="col-md-6">
        <div class="form-section">
            <h5>Informations</h5>
            <p><strong>Login:</strong> <?php echo htmlspecialchars($user['login']); ?></p>
            <p><strong>Nom:</strong> <?php echo htmlspecialchars($user['nom']); ?></p>
            <p><strong>Prénom:</strong> <?php echo htmlspecialchars($user['prenom']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
            <p><strong>Type:</strong> <?php echo $user['type'] === 1 ? 'Enseignant' : 'Étudiant'; ?></p>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="form-section">
            <h5>Changer le mot de passe</h5>
            <form method="POST">
                <div class="mb-3">
                    <label for="password" class="form-label">Nouveau mot de passe</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                    <small class="text-muted">Min. 4 caractères</small>
                </div>
                <button type="submit" class="btn btn-primary btn-sm">Mettre à jour</button>
            </form>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
