<?php
include '_conf.php';
include 'fonctions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 1) {
    header("Location: index.php");
    exit();
}

$bdd = $conn;

// Récupérer la liste des élèves avec leurs informations de stage
$query = "SELECT u.*, s.nom as stage_nom, s.adresse, s.CP, s.ville, s.tel as stage_tel, 
                 s.libelleStage, s.email as stage_email,
                 t.nom as tuteur_nom, t.prenom as tuteur_prenom, 
                 t.tel as tuteur_tel, t.email as tuteur_email
          FROM utilisateur u 
          LEFT JOIN stage s ON u.num_stage = s.num 
          LEFT JOIN tuteur t ON s.num_tuteur = t.num 
          WHERE u.type = 0";
$result = mysqli_query($bdd, $query);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des élèves</title>
    <link rel="stylesheet" href="common.css">
    <link rel="stylesheet" href="global-header.css">
</head>
<body>
    <?php afficherHeaderNavigation(); ?>
    <?php afficherHeaderPage('👨‍🎓', 'Liste des élèves', 'Vue d\'ensemble de tous les étudiants'); ?>

    <div class="container">
    <?php if (mysqli_num_rows($result) > 0): ?>
        <div style="display: flex; flex-direction: column; gap: 12px;">
            <?php while ($eleve = mysqli_fetch_assoc($result)): ?>
            <div class="profile-section" style="padding: 0;">
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 12px 14px; border-radius: 6px 6px 0 0; border-bottom: 2px solid #667eea;">
                    <h3 style="margin: 0; color: white; border: none; padding-bottom: 0; font-size: 0.95em;">👤 <?php echo htmlspecialchars($eleve['prenom'] . ' ' . $eleve['nom']); ?></h3>
                </div>
                <div style="padding: 14px;">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                        <div>
                            <label style="color: #667eea; font-size: 0.85em; font-weight: 600; display: block; margin-bottom: 4px;">Login</label>
                            <span style="color: #333; font-size: 0.95em;"><?php echo htmlspecialchars($eleve['login']); ?></span>
                        </div>
                        <div>
                            <label style="color: #667eea; font-size: 0.85em; font-weight: 600; display: block; margin-bottom: 4px;">Email</label>
                            <span style="color: #333; font-size: 0.95em;"><?php echo htmlspecialchars($eleve['email']); ?></span>
                        </div>
                    </div>
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <div style="flex: 1;">
                            <label style="color: #667eea; font-size: 0.85em; font-weight: 600; display: block; margin-bottom: 4px;">Statut stage</label>
                            <span style="display: inline-block; padding: 6px 12px; border-radius: 4px; font-size: 0.9em; font-weight: 600; <?php echo !empty($eleve['stage_nom']) ? 'background: #d4edda; color: #155724;' : 'background: #f8d7da; color: #721c24;'; ?>">
                                <?php echo !empty($eleve['stage_nom']) ? '✅ Stage renseigné' : '❌ Aucun stage'; ?>
                            </span>
                        </div>
                        <?php if (!empty($eleve['stage_nom'])): ?>
                        <a href="?view_stage=<?php echo $eleve['num']; ?>" style="background: linear-gradient(135deg, #17a2b8 0%, #0c5460 100%); color: white; padding: 6px 14px; border-radius: 4px; text-decoration: none; font-weight: 600; font-size: 0.9em; border: none; cursor: pointer; display: inline-block;">📄 Voir le stage</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div style="text-align: center; padding: 30px; color: #999;">
            <p style="font-size: 1.1em;">👥 Aucun élève trouvé</p>
        </div>
    <?php endif; ?>

    <!-- Modal pour afficher les détails du stage -->
    <?php if (isset($_GET['view_stage']) && !empty($_GET['view_stage'])): 
        $eleve_id = intval($_GET['view_stage']);
        $stage_query = "SELECT u.prenom, u.nom, s.*, t.nom as tuteur_nom, t.prenom as tuteur_prenom, 
                                t.tel as tuteur_tel, t.email as tuteur_email
                         FROM utilisateur u 
                         LEFT JOIN stage s ON u.num_stage = s.num 
                         LEFT JOIN tuteur t ON s.num_tuteur = t.num 
                         WHERE u.num = " . intval($eleve_id);
        $stage_result = mysqli_query($bdd, $stage_query);
        $stage_info = mysqli_fetch_assoc($stage_result);
    ?>
        <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); z-index: 10001; display: flex; align-items: center; justify-content: center;">
            <div style="background: white; border-radius: 10px; max-width: 600px; width: 90%; box-shadow: 0 12px 48px rgba(0,0,0,0.3);">
                <div style="background: linear-gradient(135deg, #17a2b8 0%, #0c5460 100%); padding: 16px 20px; border-radius: 10px 10px 0 0; display: flex; justify-content: space-between; align-items: center;">
                    <h2 style="margin: 0; color: white; font-size: 1.2em;">📄 Stage - <?php echo htmlspecialchars($stage_info['prenom'] . ' ' . $stage_info['nom']); ?></h2>
                    <a href="liste_eleves.php" style="color: white; font-size: 1.8em; text-decoration: none; cursor: pointer; font-weight: 300;">✕</a>
                </div>
                <div style="padding: 20px;">
                    <?php if (!empty($stage_info['nom'])): ?>
                        <div class="profile-section" style="padding: 0; margin-bottom: 15px;">
                            <div style="background: linear-gradient(135deg, #f0fff4 0%, #f5f7ff 100%); padding: 12px 14px; border-radius: 6px 6px 0 0; border-bottom: 2px solid #28a745;">
                                <h3 style="margin: 0; color: #28a745; border: none; padding-bottom: 0; font-size: 0.95em;">🏢 Entreprise</h3>
                            </div>
                            <div style="padding: 14px;">
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                    <div>
                                        <label style="color: #667eea; font-size: 0.85em; font-weight: 600; display: block; margin-bottom: 4px;">Nom</label>
                                        <span style="color: #333;"><?php echo htmlspecialchars($stage_info['nom'] ?? ''); ?></span>
                                    </div>
                                    <div>
                                        <label style="color: #667eea; font-size: 0.85em; font-weight: 600; display: block; margin-bottom: 4px;">Adresse</label>
                                        <span style="color: #333;"><?php echo htmlspecialchars($stage_info['adresse'] ?? ''); ?></span>
                                    </div>
                                    <div>
                                        <label style="color: #667eea; font-size: 0.85em; font-weight: 600; display: block; margin-bottom: 4px;">Code postal</label>
                                        <span style="color: #333;"><?php echo htmlspecialchars($stage_info['CP'] ?? ''); ?></span>
                                    </div>
                                    <div>
                                        <label style="color: #667eea; font-size: 0.85em; font-weight: 600; display: block; margin-bottom: 4px;">Ville</label>
                                        <span style="color: #333;"><?php echo htmlspecialchars($stage_info['ville'] ?? ''); ?></span>
                                    </div>
                                    <div>
                                        <label style="color: #667eea; font-size: 0.85em; font-weight: 600; display: block; margin-bottom: 4px;">Téléphone</label>
                                        <span style="color: #333;"><?php echo htmlspecialchars($stage_info['tel'] ?? ''); ?></span>
                                    </div>
                                    <div>
                                        <label style="color: #667eea; font-size: 0.85em; font-weight: 600; display: block; margin-bottom: 4px;">Email</label>
                                        <span style="color: #333;"><?php echo htmlspecialchars($stage_info['email'] ?? ''); ?></span>
                                    </div>
                                </div>
                                <div style="margin-top: 15px;">
                                    <label style="color: #667eea; font-size: 0.85em; font-weight: 600; display: block; margin-bottom: 4px;">Libellé du stage</label>
                                    <p style="color: #333; margin: 0; line-height: 1.5;"><?php echo nl2br(htmlspecialchars($stage_info['libelleStage'] ?? '')); ?></p>
                                </div>
                            </div>
                        </div>

                        <div class="profile-section" style="padding: 0;">
                            <div style="background: linear-gradient(135deg, #f0f4ff 0%, #f5f7ff 100%); padding: 12px 14px; border-radius: 6px 6px 0 0; border-bottom: 2px solid #667eea;">
                                <h3 style="margin: 0; color: #667eea; border: none; padding-bottom: 0; font-size: 0.95em;">👤 Tuteur en entreprise</h3>
                            </div>
                            <div style="padding: 14px;">
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                    <div>
                                        <label style="color: #667eea; font-size: 0.85em; font-weight: 600; display: block; margin-bottom: 4px;">Nom complet</label>
                                        <span style="color: #333;"><?php echo htmlspecialchars(($stage_info['tuteur_prenom'] ?? '') . ' ' . ($stage_info['tuteur_nom'] ?? '')); ?></span>
                                    </div>
                                    <div>
                                        <label style="color: #667eea; font-size: 0.85em; font-weight: 600; display: block; margin-bottom: 4px;">Téléphone</label>
                                        <span style="color: #333;"><?php echo htmlspecialchars($stage_info['tuteur_tel'] ?? ''); ?></span>
                                    </div>
                                    <div style="grid-column: 1 / -1;">
                                        <label style="color: #667eea; font-size: 0.85em; font-weight: 600; display: block; margin-bottom: 4px;">Email</label>
                                        <span style="color: #333;"><?php echo htmlspecialchars($stage_info['tuteur_email'] ?? ''); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div style="text-align: center; padding: 20px; background: #fff8e1; border-radius: 6px; border-left: 4px solid #ffc107;">
                            <p style="color: #856404; margin: 0;">⚠️ Cet élève n'a pas encore renseigné ses informations de stage.</p>
                        </div>
                    <?php endif; ?>
                    <div style="margin-top: 20px;">
                        <a href="liste_eleves.php" style="background: linear-gradient(135deg, #6c757d 0%, #545b62 100%); color: white; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-weight: 600; display: inline-block;">← Fermer</a>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="link-group">
        <a href="accueil.php" class="retour-btn" style="background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%); padding: 12px 28px; font-weight: 600; font-size: 1em;">🏠 Accueil</a>
    </div>
    </div>
</body>
</html>