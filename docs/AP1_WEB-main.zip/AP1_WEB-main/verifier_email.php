<?php
$pageTitle = 'Vérification Email';
require_once '_conf.php';
require_once 'fonctions.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    
    if (empty($email)) {
        $message = '<div class="alert alert-danger">Email requis</div>';
    } else {
        $message = '<div class="alert alert-success">Vérification activée. Vous pouvez maintenant vous connecter.</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background: linear-gradient(135deg, #007bff 0%, #0056b3 100%); min-height: 100vh; display: flex; align-items: center;">
    <div style="background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.2); max-width: 400px; margin: auto; width: 100%;">
        <h2 style="color: #007bff; text-align: center; margin-bottom: 2rem;">✉️ Vérification Email</h2>
        
        <?php echo $message; ?>
        
        <p class="text-center text-muted">Votre compte est activé. <a href="index.php">Retour à la connexion</a></p>
    </div>
</body>
</html>
