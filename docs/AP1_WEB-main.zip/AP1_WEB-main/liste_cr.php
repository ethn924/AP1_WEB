<?php
require_once '_conf.php';
require_once 'fonctions.php';

if (!$loggedIn || $userType !== 0) {
    header('Location: index.php');
    exit;
}

$pageTitle = 'Mes Comptes Rendus';
require_once 'header.php';

$bdd = $conn;
$user_id = $userId;

if (isset($_POST['delete_cr'])) {
    $cr_id = (int)$_POST['delete_cr'];
    $check = fetchOne("SELECT * FROM cr WHERE num = $cr_id AND num_utilisateur = $user_id");
    
    if ($check) {
        marquerCRCommeSupprimes($cr_id);
        header('Location: liste_cr.php');
        exit;
    }
}

$query = "SELECT * FROM cr WHERE num_utilisateur = $user_id AND supprime = 0 ORDER BY datetime DESC";
$result = mysqli_query($bdd, $query);

$cr_detail = null;
if (isset($_GET['detail']) && !empty($_GET['detail'])) {
    $cr_num = (int)$_GET['detail'];
    $detail_query = "SELECT * FROM cr WHERE num = $cr_num AND num_utilisateur = $user_id";
    $detail_result = mysqli_query($bdd, $detail_query);
    if (mysqli_num_rows($detail_result) > 0) {
        $cr_detail = mysqli_fetch_assoc($detail_result);
    }
}
?>

<div class="page-header">
    <h1>📋 Mes Comptes Rendus</h1>
    <p>Consultez et gérez tous vos comptes rendus</p>
</div>

<?php if (mysqli_num_rows($result) > 0): ?>
<div class="card">
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>📝 Titre</th>
                    <th>📅 Date</th>
                    <th>✓ Statut</th>
                    <th>⚙️ Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($cr = mysqli_fetch_assoc($result)): 
                    $commentaires = getCommentaires($cr['num']);
                    $pieces_jointes = getPiecesJointes($cr['num']);
                    $statut_vu = $cr['vu'] == 1 ? "✅ Consulté" : "⏳ En attente";
                ?>
                <tr>
                    <td>
                        <?php 
                        $titre = htmlspecialchars($cr['titre'] ?? 'Sans titre');
                        echo (strlen($titre) > 50) ? substr($titre, 0, 50) . '...' : $titre;
                        ?>
                    </td>
                    <td style="font-size: 0.9em; color: #666;">
                        <?php echo formatDate($cr['datetime']); ?>
                    </td>
                    <td>
                        <span class="status-badge <?php echo $cr['vu'] ? 'status-approved' : 'status-draft'; ?>">
                            <?php echo $statut_vu; ?>
                        </span>
                    </td>
                    <td>
                        <div style="display: flex; gap: 6px;">
                            <a href="?detail=<?php echo $cr['num']; ?>" class="btn btn-sm btn-secondary" title="Voir le détail">👁️</a>
                            <a href="editer_cr.php?id=<?php echo $cr['num']; ?>" class="btn btn-sm btn-primary" title="Modifier">✏️</a>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="delete_cr" value="<?php echo $cr['num']; ?>">
                                <button type="submit" class="btn btn-sm btn-danger" title="Supprimer" onclick="return confirm('Êtes-vous sûr ?');">🗑️</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
<?php else: ?>
<div class="card">
    <div class="card-body text-center" style="padding: 50px 20px;">
        <p style="color: var(--primary); font-size: 1.2em; font-weight: 700; margin-bottom: 20px;">📭 Aucun compte rendu pour le moment</p>
        <p style="color: #666; margin-bottom: 25px;">Commencez à rédiger votre première expérience en stage</p>
        <a href="editer_cr.php" class="btn btn-primary">✍️ Créer votre premier CR</a>
    </div>
</div>
<?php endif; ?>

<?php if ($cr_detail): 
    $commentaires = getCommentaires($cr_detail['num']);
    $pieces_jointes = getPiecesJointes($cr_detail['num']);
?>
<div class="modal-overlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center; overflow-y: auto;">
    <div class="modal-content" style="background: white; border-radius: 8px; max-width: 800px; width: 90%; margin: 30px auto; box-shadow: var(--shadow-lg);">
        <div style="background: var(--primary); padding: 20px; border-radius: 8px 8px 0 0; display: flex; justify-content: space-between; align-items: center;">
            <h2 style="margin: 0; color: white; font-size: 1.2em;">📋 <?php echo htmlspecialchars($cr_detail['titre'] ?? 'Compte Rendu'); ?></h2>
            <a href="liste_cr.php" style="color: white; font-size: 1.8em; text-decoration: none; cursor: pointer;">✕</a>
        </div>

        <div style="padding: 20px; max-height: 70vh; overflow-y: auto;">
            <div class="card mb-3">
                <div class="card-header">📄 Informations</div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label style="color: var(--primary); font-weight: 600; display: block; margin-bottom: 4px;">Date de création</label>
                            <span><?php echo formatDate($cr_detail['datetime']); ?></span>
                        </div>
                        <div>
                            <label style="color: var(--primary); font-weight: 600; display: block; margin-bottom: 4px;">Statut</label>
                            <span class="status-badge <?php echo $cr_detail['vu'] ? 'status-approved' : 'status-draft'; ?>">
                                <?php echo $cr_detail['vu'] == 1 ? '✅ Consulté' : '⏳ Non consulté'; ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <?php if (!empty($cr_detail['description'])): ?>
            <div class="card mb-3">
                <div class="card-header">📝 Description</div>
                <div class="card-body">
                    <p style="color: #666; line-height: 1.6; margin: 0;"><?php echo htmlspecialchars($cr_detail['description']); ?></p>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($cr_detail['contenu_html']) && !empty(trim(strip_tags($cr_detail['contenu_html'])))): ?>
            <div class="card mb-3">
                <div class="card-header">✍️ Contenu</div>
                <div class="card-body" style="color: #555; line-height: 1.6;">
                    <?php 
                    $html = $cr_detail['contenu_html'];
                    echo $html;
                    ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($pieces_jointes)): ?>
            <div class="card mb-3">
                <div class="card-header">📎 Pièces jointes</div>
                <div class="card-body">
                    <?php foreach ($pieces_jointes as $piece): ?>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px; background: #f9fafb; border-radius: 4px; margin-bottom: 6px;">
                            <span>📄 <?php echo htmlspecialchars($piece['nom_fichier']); ?> (<?php echo formaterTailleFichier($piece['taille']); ?>)</span>
                            <a href="telecharger.php?id=<?php echo $piece['id']; ?>" target="_blank" class="btn btn-sm btn-info">⬇️ DL</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">💬 Commentaires</div>
                <div class="card-body">
                    <?php if (!empty($commentaires)): ?>
                        <div style="display: flex; flex-direction: column; gap: 12px;">
                            <?php foreach ($commentaires as $commentaire): ?>
                                <div style="padding: 12px; background: #f9fafb; border-left: 3px solid var(--info); border-radius: 4px;">
                                    <div style="margin-bottom: 6px;">
                                        <strong>👨‍🏫 <?php echo htmlspecialchars($commentaire['prenom'] . ' ' . $commentaire['nom']); ?></strong>
                                        <span style="color: #999; font-size: 0.85em;"> — <?php echo formatDate($commentaire['date_creation']); ?></span>
                                    </div>
                                    <p style="margin: 0; line-height: 1.5; color: #555;">
                                        <?php echo nl2br(htmlspecialchars($commentaire['commentaire'])); ?>
                                    </p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div style="text-align: center; padding: 20px; color: #999;">
                            <p>Aucun commentaire pour le moment</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div style="margin-top: 20px;">
                <a href="liste_cr.php" class="btn btn-secondary">← Fermer</a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

</main>

<?php require_once 'footer.php'; ?>
