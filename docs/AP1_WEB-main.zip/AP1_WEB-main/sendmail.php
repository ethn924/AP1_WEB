<?php
require_once '_conf.php';
require_once 'fonctions.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login'] ?? '';
    
    if (empty($login)) {
        $message = '<div class="alert alert-danger">Login requis</div>';
    } else {
        $user = getUserByLogin($login);
        
        if ($user) {
            $message = '<div class="alert alert-success">Si ce compte existe, un email de réinitialisation sera envoyé.</div>';
        } else {
            $message = '<div class="alert alert-danger">Compte non trouvé</div>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialiser mot de passe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .reset-container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            max-width: 400px;
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="reset-container">
        <h2 style="color: #007bff; text-align: center; margin-bottom: 2rem;">🔐 Réinitialiser</h2>
        
        <?php echo $message; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label for="login" class="form-label">Login</label>
                <input type="text" class="form-control" id="login" name="login" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Envoyer</button>
        </form>
        
        <p class="text-center mt-3">
            <a href="index.php">Retour à la connexion</a>
        </p>
    </div>
</body>
</html>
