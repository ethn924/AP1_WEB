<?php
require_once '_conf.php';

function echapper($str) {
    global $conn;
    if (!$conn) return addslashes($str);
    return mysqli_real_escape_string($conn, $str);
}

function q($str, $connection = null) {
    global $conn;
    if ($connection) {
        return mysqli_real_escape_string($connection, $str);
    }
    return echapper($str);
}

function logError($msg) {
    $file = __DIR__ . '/logs/error_' . date('Y-m-d') . '.log';
    @mkdir(__DIR__ . '/logs', 0777, true);
    error_log('[' . date('H:i:s') . '] ' . $msg . "\n", 3, $file);
}

function getUser($id) {
    global $conn;
    $id = (int)$id;
    $result = @mysqli_query($conn, "SELECT * FROM utilisateur WHERE num=$id");
    if (!$result) {
        logError("getUser: " . mysqli_error($conn));
        return null;
    }
    return mysqli_fetch_assoc($result);
}

function getUserByLogin($login) {
    global $conn;
    $login = echapper($login);
    $result = @mysqli_query($conn, "SELECT * FROM utilisateur WHERE login='$login'");
    if (!$result) {
        logError("getUserByLogin: " . mysqli_error($conn));
        return null;
    }
    return mysqli_fetch_assoc($result);
}

function verifyPassword($login, $password) {
    $user = getUserByLogin($login);
    if ($user && md5($password) === $user['mdp']) {
        return $user;
    }
    return false;
}

function createCR($title, $description, $userId) {
    global $conn;
    $title = echapper($title);
    $description = echapper($description);
    $userId = (int)$userId;
    
    $query = "INSERT INTO cr (titre, description, num_utilisateur, date, datetime) 
              VALUES ('$title', '$description', $userId, CURDATE(), NOW())";
    
    if (@mysqli_query($conn, $query)) {
        return mysqli_insert_id($conn);
    }
    logError("createCR: " . mysqli_error($conn));
    return false;
}

function getCR($id) {
    global $conn;
    $id = (int)$id;
    $result = @mysqli_query($conn, "SELECT cr.*, utilisateur.login, utilisateur.nom, utilisateur.prenom 
                                   FROM cr 
                                   LEFT JOIN utilisateur ON cr.num_utilisateur = utilisateur.num 
                                   WHERE cr.num=$id");
    if (!$result) {
        logError("getCR: " . mysqli_error($conn));
        return null;
    }
    return mysqli_fetch_assoc($result);
}

function getUserCRs($userId) {
    global $conn;
    $userId = (int)$userId;
    $result = @mysqli_query($conn, "SELECT cr.*, statuts_cr.statut 
                                   FROM cr 
                                   LEFT JOIN statuts_cr ON cr.num = statuts_cr.cr_id 
                                   WHERE cr.num_utilisateur=$userId AND cr.supprime=0 
                                   ORDER BY cr.datetime DESC");
    if (!$result) {
        logError("getUserCRs: " . mysqli_error($conn));
        return [];
    }
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function getAllCRsForTeacher($teacherId) {
    global $conn;
    $teacherId = (int)$teacherId;
    $result = mysqli_query($conn, "SELECT cr.*, utilisateur.login, utilisateur.nom, utilisateur.prenom, 
                                   statuts_cr.statut, COUNT(commentaires.id) as nb_comments
                                   FROM cr 
                                   LEFT JOIN utilisateur ON cr.num_utilisateur = utilisateur.num 
                                   LEFT JOIN statuts_cr ON cr.num = statuts_cr.cr_id 
                                   LEFT JOIN commentaires ON cr.num = commentaires.cr_id 
                                   WHERE cr.supprime=0 
                                   GROUP BY cr.num 
                                   ORDER BY cr.datetime DESC");
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function updateCR($id, $title, $description, $html) {
    global $conn;
    $id = (int)$id;
    $title = echapper($title);
    $description = echapper($description);
    $html = echapper($html);
    
    $query = "UPDATE cr SET titre='$title', description='$description', contenu_html='$html', datetime=NOW() WHERE num=$id";
    $result = @mysqli_query($conn, $query);
    if (!$result) {
        logError("updateCR: " . mysqli_error($conn));
        return false;
    }
    return true;
}

function deleteCR($id) {
    global $conn;
    $id = (int)$id;
    return mysqli_query($conn, "UPDATE cr SET supprime=1, date_suppression=NOW() WHERE num=$id");
}

function addComment($crId, $teacherId, $comment) {
    global $conn;
    $crId = (int)$crId;
    $teacherId = (int)$teacherId;
    $comment = echapper($comment);
    
    $query = "INSERT INTO commentaires (cr_id, professeur_id, commentaire, date_creation) 
              VALUES ($crId, $teacherId, '$comment', NOW())";
    
    if (mysqli_query($conn, $query)) {
        return mysqli_insert_id($conn);
    }
    return false;
}

function getComments($crId) {
    global $conn;
    $crId = (int)$crId;
    $result = @mysqli_query($conn, "SELECT c.*, u.login, u.nom, u.prenom 
                                   FROM commentaires c 
                                   LEFT JOIN utilisateur u ON c.professeur_id = u.num 
                                   WHERE c.cr_id=$crId 
                                   ORDER BY c.date_creation DESC");
    if (!$result) {
        logError("getComments: " . mysqli_error($conn));
        return [];
    }
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function updateCRStatus($crId, $status, $teacherId = null, $notes = null) {
    global $conn;
    $crId = (int)$crId;
    $status = echapper($status);
    $notes = $notes ? echapper($notes) : null;
    
    $query = "UPDATE statuts_cr SET statut='$status'";
    
    if ($status === 'soumis') {
        $query .= ", date_soumission=NOW()";
    } elseif ($status === 'en_evaluation') {
        $query .= ", date_evaluation=NOW(), professeur_evaluateur_id=" . (int)$teacherId;
    } elseif ($status === 'approuve') {
        $query .= ", date_approbation=NOW(), professeur_evaluateur_id=" . (int)$teacherId;
        if ($notes) {
            $query .= ", notes_evaluation='$notes'";
        }
    }
    
    $query .= " WHERE cr_id=$crId";
    $result = @mysqli_query($conn, $query);
    if (!$result) {
        logError("updateCRStatus: " . mysqli_error($conn));
        return false;
    }
    return true;
}

function getCRStatus($crId) {
    global $conn;
    $crId = (int)$crId;
    $result = mysqli_query($conn, "SELECT * FROM statuts_cr WHERE cr_id=$crId");
    return mysqli_fetch_assoc($result);
}

function initCRStatus($crId) {
    global $conn;
    $crId = (int)$crId;
    
    $check = @mysqli_query($conn, "SELECT id FROM statuts_cr WHERE cr_id=$crId");
    if (!$check) {
        logError("initCRStatus check: " . mysqli_error($conn));
        return false;
    }
    if (mysqli_num_rows($check) === 0) {
        $query = "INSERT INTO statuts_cr (cr_id, statut, date_limite_soumission) 
                  VALUES ($crId, 'brouillon', DATE_ADD(CURDATE(), INTERVAL 30 DAY))";
        $result = @mysqli_query($conn, $query);
        if (!$result) {
            logError("initCRStatus insert: " . mysqli_error($conn));
            return false;
        }
        return true;
    }
    return true;
}

function addNotification($userId, $type, $title, $message, $link = null) {
    global $conn;
    $userId = (int)$userId;
    $type = echapper($type);
    $title = echapper($title);
    $message = echapper($message);
    $link = $link ? echapper($link) : null;
    
    $query = "INSERT INTO notifications (utilisateur_id, type, titre, message, lien, date_creation) 
              VALUES ($userId, '$type', '$title', '$message', '$link', NOW())";
    
    return mysqli_query($conn, $query);
}

function getUserNotifications($userId, $limit = 10) {
    global $conn;
    $userId = (int)$userId;
    $limit = (int)$limit;
    
    $result = mysqli_query($conn, "SELECT * FROM notifications 
                                   WHERE utilisateur_id=$userId 
                                   ORDER BY date_creation DESC 
                                   LIMIT $limit");
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function getUnreadNotificationsCount($userId) {
    global $conn;
    $userId = (int)$userId;
    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM notifications 
                                   WHERE utilisateur_id=$userId AND lue=0");
    $row = mysqli_fetch_assoc($result);
    return $row['count'];
}

function markNotificationAsRead($id) {
    global $conn;
    $id = (int)$id;
    return mysqli_query($conn, "UPDATE notifications SET lue=1 WHERE id=$id");
}

function getGroups() {
    global $conn;
    $result = @mysqli_query($conn, "SELECT g.*, u.login as prof_login, u.nom, u.prenom 
                                   FROM groupes g 
                                   LEFT JOIN utilisateur u ON g.professeur_responsable_id = u.num 
                                   WHERE g.actif=1 
                                   ORDER BY g.nom");
    if (!$result) {
        logError("getGroups: " . mysqli_error($conn));
        return [];
    }
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function getGroupMembers($groupId) {
    global $conn;
    $groupId = (int)$groupId;
    $result = mysqli_query($conn, "SELECT u.* 
                                   FROM membres_groupe mg 
                                   JOIN utilisateur u ON mg.utilisateur_id = u.num 
                                   WHERE mg.groupe_id=$groupId AND mg.statut='actif'");
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function createAutoSave($crId, $userId, $html, $description) {
    global $conn;
    $crId = (int)$crId;
    $userId = (int)$userId;
    $html = echapper($html);
    $description = echapper($description);
    
    $query = "INSERT INTO sauvegardes_auto (cr_id, utilisateur_id, contenu_html, description, date_sauvegarde) 
              VALUES ($crId, $userId, '$html', '$description', NOW())";
    
    return mysqli_query($conn, $query);
}

function getLastAutoSave($crId) {
    global $conn;
    $crId = (int)$crId;
    $result = mysqli_query($conn, "SELECT * FROM sauvegardes_auto 
                                   WHERE cr_id=$crId 
                                   ORDER BY date_sauvegarde DESC 
                                   LIMIT 1");
    return mysqli_fetch_assoc($result);
}

function formatDate($date) {
    if (!$date) return '—';
    $dt = new DateTime($date);
    return $dt->format('d/m/Y H:i');
}

function getStatusBadge($status) {
    $badges = [
        'brouillon' => '<span class="badge badge-secondary">Brouillon</span>',
        'soumis' => '<span class="badge badge-primary">Soumis</span>',
        'en_evaluation' => '<span class="badge badge-warning">En évaluation</span>',
        'approuve' => '<span class="badge badge-success">Approuvé</span>'
    ];
    return $badges[$status] ?? '<span class="badge badge-dark">' . $status . '</span>';
}

function checkPermission($crId, $userId) {
    global $conn;
    $crId = (int)$crId;
    $userId = (int)$userId;
    
    $result = mysqli_query($conn, "SELECT num_utilisateur FROM cr WHERE num=$crId");
    $cr = mysqli_fetch_assoc($result);
    
    return $cr && $cr['num_utilisateur'] === $userId;
}

function logger($msg, $userId = null, $file = 'app.log') {
    logError($msg);
}

function sauvegarderFichier($file, $crId) {
    global $conn;
    $crId = (int)$crId;
    $uploadDir = __DIR__ . '/uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
    
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx'];
    if (!in_array($ext, $allowed)) throw new Exception("Type non autorisé");
    if ($file['size'] > 10485760) throw new Exception("Fichier trop volumineux");
    
    $filename = md5(uniqid()) . '.' . $ext;
    $path = $uploadDir . $filename;
    if (!move_uploaded_file($file['tmp_name'], $path)) throw new Exception("Erreur upload");
    
    $originalName = echapper($file['name']);
    $query = "INSERT INTO pieces_jointes (cr_id, nom_fichier, nom_original, date_upload) VALUES ($crId, '$filename', '$originalName', NOW())";
    mysqli_query($conn, $query);
}

function afficherHeaderNavigation() {
    echo '<header><nav style="padding:10px 20px; background:#333; color:white;"><a href="accueil.php" style="color:white; text-decoration:none;">Accueil</a></nav></header>';
}

function afficherModalPersonnalisee($titre, $message, $id) {
    echo '<div id="' . htmlspecialchars($id) . '" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%,-50%); background:white; padding:20px; border-radius:8px; box-shadow:0 0 20px rgba(0,0,0,0.3); z-index:9999;"><h3>' . htmlspecialchars($titre) . '</h3><p>' . htmlspecialchars($message) . '</p><button onclick="this.parentElement.style.display=\'none\'">Fermer</button></div>';
}

function afficherHeaderPage($icon, $titre, $desc = '') {
    echo '<div style="padding:20px; background:#f5f5f5; border-bottom:1px solid #ddd;"><h1 style="margin:0;">' . htmlspecialchars($icon) . ' ' . htmlspecialchars($titre) . '</h1>';
    if ($desc) echo '<p style="margin:5px 0 0 0; color:#666;">' . htmlspecialchars($desc) . '</p>';
    echo '</div>';
}

function afficherAlerte($type, $message) {
    $colors = ['success' => '#d4edda', 'error' => '#f8d7da', 'info' => '#d1ecf1'];
    $color = $colors[$type] ?? '#d1ecf1';
    echo '<div style="padding:12px; margin:10px 0; background-color:' . $color . '; border:1px solid #ddd; border-radius:4px;">' . htmlspecialchars($message) . '</div>';
}

function formatDateTimeFrench($date) {
    if (!$date) return '—';
    $dt = new DateTime($date);
    $months = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
    $month = $months[(int)$dt->format('m') - 1];
    return $dt->format('d') . ' ' . $month . ' ' . $dt->format('Y \à H:i');
}

function formatDateFrench($date) {
    if (!$date) return '—';
    $dt = new DateTime($date);
    $months = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
    $month = $months[(int)$dt->format('m') - 1];
    return $dt->format('d') . ' ' . $month . ' ' . $dt->format('Y');
}

function formaterTailleFichier($bytes) {
    $units = ['B', 'KB', 'MB', 'GB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= (1 << (10 * $pow));
    return round($bytes, 2) . ' ' . $units[$pow];
}

function i($condition) {
    return $condition ? 1 : 0;
}

function fetchOne($query, $connection = null) {
    global $conn;
    $db = $connection ?: $conn;
    $result = mysqli_query($db, $query);
    return $result ? mysqli_fetch_assoc($result) : null;
}

function fetchAll($query, $connection = null) {
    global $conn;
    $db = $connection ?: $conn;
    $result = mysqli_query($db, $query);
    return $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];
}

function marquerCRCommeSupprimes($crId, $connection = null) {
    global $conn;
    $db = $connection ?: $conn;
    $crId = (int)$crId;
    return mysqli_query($db, "UPDATE cr SET supprime=1, date_suppression=NOW() WHERE num=$crId");
}

function getCommentaires($crId, $connection = null) {
    return getComments($crId);
}

function getPiecesJointes($crId, $connection = null) {
    global $conn;
    $db = $connection ?: $conn;
    $crId = (int)$crId;
    $result = mysqli_query($db, "SELECT * FROM pieces_jointes WHERE cr_id=$crId ORDER BY date_upload DESC");
    return $result ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];
}

function creerNotificationAvecAuteur($userId, $type, $titre, $message, $auteurId = null, $link = null) {
    return addNotification($userId, $type, $titre, $message, $link);
}

function ajouterCommentaire($crId, $teacherId, $comment) {
    return addComment($crId, $teacherId, $comment);
}

function getCRWithStudent($crId, $connection = null) {
    global $conn;
    $db = $connection ?: $conn;
    $crId = (int)$crId;
    $result = mysqli_query($db, "SELECT cr.*, utilisateur.login, utilisateur.nom, utilisateur.prenom FROM cr LEFT JOIN utilisateur ON cr.num_utilisateur = utilisateur.num WHERE cr.num=$crId");
    return $result ? mysqli_fetch_assoc($result) : null;
}
?>
